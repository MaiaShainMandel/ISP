import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.input.*;
import javafx.scene.control.Label;
import javafx.animation.Timeline;
import java.text.*;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.animation.Animation;


/** The Room1 class is basically one third of our entire program. It is the first level of our game, which
 * underlines and identifies the issues of climate change. It gives the user facts about our environment to get them
 * thinking and to want to make a change. Lastly, it puts together a nice quote at the bottom which rhymes so that
 * it can be catchy and sound appealing to the user.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 23 2019: Class created by Megan. Image background created by Megan and imported.
 *
 * May 24 2019: Edited by Maia, added buttons.
 *
 * May 27 2019: Maia added the clues and the words that came out of each clue, in addition the the object after it had been clicked.
 *
 * May 29 2019: Megan and Maia added the sentence at the bottom with the fill in the blanks.
 *
 * May 31 2019: Edited by Megan so that the LevelRoom class contained methods used by this class.
 *
 * June 2 2019: Megan added timer.
 *
 * Approximate time spent working on Room1: 5 hours
 *</pre>
 **/
public class Room1 extends LevelRoom {
  /**
  *Holds the basic background colour used in many shapes around the room
  */
  private final Color floor = Color.rgb (62, 72, 81);
  private Group root;
  Scene scene;
  private final Stage stage;

  public Room1 (Stage stage)
  {
    this.stage = stage;
    Main.startTime = System.nanoTime()/1000000000;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains pictures that were imported. Additionally, a try 
   * and catch to bring the user back to Main Menu. 
   * Also, this method is used to make all of the clues, edit them once clicked, allow for the words to be dragged
   * and placed into the sentence, and finally calls inBetweenRoom1 once finished.
   *
   **/
  public void start() {
    Image image = new Image(("graphics/Rooms.png"));
    Image help = new Image(("graphics/help.png"));
    Image speechBubbleImage = new Image(("graphics/speechBubble.png"));
    Image bin = new Image(("graphics/bin.png"));
    Image bin2 = new Image(("graphics/bin2.png"));
    Image tv = new Image(("graphics/tv.png"));
    Image tv2 = new Image(("graphics/tv2.png"));
    Image flower = new Image(("graphics/flower.png"));
    Image flower2 = new Image(("graphics/flower2.png"));
    Image bulb = new Image(("graphics/bulb.png"));
    Image bulb2 = new Image(("graphics/bulb2.png"));
    Image plug = new Image(("graphics/plug.png"));
    Image shelf = new Image(("graphics/shelf.png"));
    Image shelf2 = new Image(("graphics/shelf2.png"));
    Image door = new Image(("graphics/door.png"));
    root = new Group(imageCreate (image, 0, 0, 1350, 900, true));
    scene = new Scene(root, 900, 600);

    //Exit Button
    Button btn = new Button();
    btn.setText("Stop");
    btn.setStyle ("-fx-background-color: #f1a6a6");
    btn.setOnAction(new EventHandler<ActionEvent>() {
                      @Override
                      public void handle(ActionEvent event)
                      {
                        MainMenu m = new MainMenu(stage);
                        m.start();
                        stage.setScene (m.scene);
                      }
                    }
    );
    //Done button
    Button btn2 = new Button();
    btn2.setText("Got it!");
    btn2.setStyle ("-fx-background-color: #f1a6a6");
    btn2.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event)
                       {
                         InbetweenRoom1 i1 = new InbetweenRoom1(stage);
                         i1.start();
                         stage.setScene (i1.scene);
                       }
                     }
    );
    btn2.setLayoutX(415);
    btn2.setLayoutY(510);
    btn.setLayoutX(850);
    btn.setLayoutY(18);
    //add button
    root.getChildren().add(btn);
    root.getChildren ().add(rect(0, 500, 900, 100, Color.web("rgb(145, 191, 223)")));
    root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));

    //First Clue
    final Text source = new Text(35, 300, "BE");
    source.setScaleX(2.0);
    source.setScaleY(2.0);

    final Text target = new Text(45, 555, "___");
    target.setScaleX(2.0);
    target.setScaleY(2.0);

    source.setOnDragDetected(new EventHandler <MouseEvent>() {
      public void handle(MouseEvent event) {

        /* allow any transfer mode */
        Dragboard db = source.startDragAndDrop(TransferMode.ANY);

        /* put a string on dragboard */
        ClipboardContent content = new ClipboardContent();
        content.putString(source.getText());
        db.setContent(content);

        event.consume();
      }
    });

    target.setOnDragOver(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {

        /* accept it only if it is  not dragged from the same node
         * and if it has a string data */
        if (event.getGestureSource() != target &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("BE")) {
          /* allow for both copying and moving, whatever user chooses */
          event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
      }
    });

    target.setOnDragEntered(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture entered the target */
        /* show to the user that it is an actual gesture target */
        if (event.getGestureSource() != target &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("BE")) {
          target.setFill(Color.GREEN);
        }
        else if (event.getGestureSource() != target &&
                event.getDragboard().hasString()&&!event.getDragboard().getString().equals("BE")) {
          target.setFill(Color.RED);
        }

        event.consume();
      }
    });

    target.setOnDragExited(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* mouse moved away, remove the graphical cues */
        target.setFill(Color.BLACK);
        event.consume();
      }
    });

    target.setOnDragDropped(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if there is a string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();
        boolean success = false;
        if (db.hasString()&&db.getString().equals("BE")) {
          target.setText(db.getString());
          success = true;
        }
        /* let the source know whether the string was successfully
         * transferred and used */
        event.setDropCompleted(success);

        event.consume();
      }
    });

    source.setOnDragDone(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture ended */
        /* if the data was successfully moved, clear it */
        if (event.getTransferMode() == TransferMode.MOVE) {
          source.setText("");
          setTrue(0);
        }

        event.consume();
        if (checkDone())
        {
          root.getChildren().add(btn2);
        }
      }
    });

    //Second Clue
    final Text source2 = new Text(750, 200, "PART");
    source2.setScaleX(2.0);
    source2.setScaleY(2.0);

    final Text target2 = new Text(130, 555, "_____");
    target2.setScaleX(2.0);
    target2.setScaleY(2.0);
    source2.setOnDragDetected(new EventHandler <MouseEvent>() {
      public void handle(MouseEvent event) {

        /* allow any transfer mode */
        Dragboard db = source2.startDragAndDrop(TransferMode.ANY);

        /* put a string on dragboard */
        ClipboardContent content = new ClipboardContent();
        content.putString(source2.getText());
        db.setContent(content);

        event.consume();
      }
    });

    target2.setOnDragOver(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {

        /* accept it only if it is  not dragged from the same node
         * and if it has a string data */
        if (event.getGestureSource() != target2 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("PART")) {
          /* allow for both copying and moving, whatever user chooses */
          event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
      }
    });

    target2.setOnDragEntered(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture entered the target */
        /* show to the user that it is an actual gesture target2 */
        if (event.getGestureSource() != target2 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("PART")) {
          target2.setFill(Color.GREEN);
        }
        else if (event.getGestureSource() != target2 &&
                event.getDragboard().hasString()&&!event.getDragboard().getString().equals("PART")) {
          target2.setFill(Color.RED);
        }
        event.consume();
      }
    });

    target2.setOnDragExited(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* mouse moved away, remove the graphical cues */
        target2.setFill(Color.BLACK);
        event.consume();
      }
    });

    target2.setOnDragDropped(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if there is a string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();
        boolean success = false;
        if (db.hasString()&&db.getString().equals("PART")) {
          target2.setText(db.getString());
          success = true;
        }
        /* let the source know whether the string was successfully
         * transferred and used */
        event.setDropCompleted(success);

        event.consume();
      }
    });

    source2.setOnDragDone(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture ended */
        /* if the data was successfully moved, clear it */
        if (event.getTransferMode() == TransferMode.MOVE) {
          source2.setText("");
          setTrue(1);
        }
        event.consume();
        if (checkDone())
        {
          root.getChildren().add(btn2);
        }
      }
    });

    //Clue 3
    final Text source3 = new Text(335, 70, "SOLUTION");
    source3.setScaleX(2.0);
    source3.setScaleY(2.0);

    final Text target3 = new Text(330, 555, "___________");
    target3.setScaleX(2.0);
    target3.setScaleY(2.0);
    source3.setOnDragDetected(new EventHandler <MouseEvent>() {
      public void handle(MouseEvent event) {
        /* allow any transfer mode */
        Dragboard db = source3.startDragAndDrop(TransferMode.ANY);
        /* put a string on dragboard */
        ClipboardContent content = new ClipboardContent();
        content.putString(source3.getText());
        db.setContent(content);
        event.consume();
      }
    });

    target3.setOnDragOver(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {

        /* accept it only if it is  not dragged from the same node
         * and if it has a string data */
        if (event.getGestureSource() != target3 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("SOLUTION")) {
          /* allow for both copying and moving, whatever user chooses */
          event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
      }
    });

    target3.setOnDragEntered(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture entered the target */
        /* show to the user that it is an actual gesture target */
        if (event.getGestureSource() != target3 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("SOLUTION")) {
          target3.setFill(Color.GREEN);
        }
        else if (event.getGestureSource() != target3 &&
                event.getDragboard().hasString()&&!event.getDragboard().getString().equals("SOLUTION"))
        {
          target3.setFill(Color.RED);
        }
        event.consume();
      }
    });

    target3.setOnDragExited(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* mouse moved away, remove the graphical cues */
        target3.setFill(Color.BLACK);
        event.consume();
      }
    });

    target3.setOnDragDropped(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if there is a string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();
        boolean success = false;
        if (db.hasString()&&db.getString().equals("SOLUTION")) {
          target3.setText(db.getString());
          success = true;
        }
        /* let the source know whether the string was successfully
         * transferred and used */
        event.setDropCompleted(success);
        event.consume();
      }
    });

    source3.setOnDragDone(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if the data was successfully moved, clear it */
        if (event.getTransferMode() == TransferMode.MOVE) {
          source3.setText("");
          setTrue(2);
        }
        event.consume();
        if (checkDone())
        {
          root.getChildren().add(btn2);
        }
      }
    });

    //Clue Four
    final Text source4 = new Text(660, 250, "NOT");
    source4.setScaleX(2.0);
    source4.setScaleY(2.0);

    final Text target4 = new Text(475, 555, "_____");
    target4.setScaleX(2.0);
    target4.setScaleY(2.0);

    source4.setOnDragDetected(new EventHandler <MouseEvent>() {
      public void handle(MouseEvent event) {
        /* allow any transfer mode */
        Dragboard db = source4.startDragAndDrop(TransferMode.ANY);
        /* put a string on dragboard */
        ClipboardContent content = new ClipboardContent();
        content.putString(source4.getText());
        db.setContent(content);
        event.consume();
      }
    });

    target4.setOnDragOver(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {

        /* accept it only if it is  not dragged from the same node
         * and if it has a string data */
        if (event.getGestureSource() != target4 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("NOT")) {
          /* allow for both copying and moving, whatever user chooses */
          event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
      }
    });

    target4.setOnDragEntered(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture entered the target */
        /* show to the user that it is an actual gesture target */
        if (event.getGestureSource() != target4 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("NOT")) {
          target4.setFill(Color.GREEN);
        }
        else if (event.getGestureSource() != target4 &&
                event.getDragboard().hasString()&&!event.getDragboard().getString().equals("NOT"))
        {
          target4.setFill(Color.RED);
        }
        event.consume();
      }
    });

    target4.setOnDragExited(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* mouse moved away, remove the graphical cues */
        target4.setFill(Color.BLACK);
        event.consume();
      }
    });

    target4.setOnDragDropped(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if there is a string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();
        boolean success = false;
        if (db.hasString()&&db.getString().equals("NOT")) {
          target4.setText(db.getString());
          success = true;
        }
        /* let the source know whether the string was successfully
         * transferred and used */
        event.setDropCompleted(success);
        event.consume();
      }
    });

    source4.setOnDragDone(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if the data was successfully moved, clear it */
        if (event.getTransferMode() == TransferMode.MOVE) {
          source4.setText("");
          setTrue(3);
        }
        event.consume();
        if (checkDone())
        {
          root.getChildren().add(btn2);
        }
      }
    });

    //Clue Five
    final Text source5 = new Text(280, 220, "POLLUTION");
    source5.setScaleX(2.0);
    source5.setScaleY(2.0);

    final Text target5 = new Text(750, 555, "___________");
    target5.setScaleX(2.0);
    target5.setScaleY(2.0);

    source5.setOnDragDetected(new EventHandler <MouseEvent>() {
      public void handle(MouseEvent event) {
        /* allow any transfer mode */
        Dragboard db = source5.startDragAndDrop(TransferMode.ANY);
        /* put a string on dragboard */
        ClipboardContent content = new ClipboardContent();
        content.putString(source5.getText());
        db.setContent(content);
        event.consume();
      }
    });

    target5.setOnDragOver(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {

        /* accept it only if it is  not dragged from the same node
         * and if it has a string data */
        if (event.getGestureSource() != target5 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("POLLUTION")) {
          /* allow for both copying and moving, whatever user chooses */
          event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
      }
    });

    target5.setOnDragEntered(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* the drag-and-drop gesture entered the target */
        /* show to the user that it is an actual gesture target */
        if (event.getGestureSource() != target5 &&
                event.getDragboard().hasString()&&event.getDragboard().getString().equals("POLLUTION")) {
          target5.setFill(Color.GREEN);
        }
        else if (event.getGestureSource() != target5 &&
                event.getDragboard().hasString()&&!event.getDragboard().getString().equals("POLLUTION"))
        {
          target5.setFill(Color.RED);
        }
        event.consume();
      }
    });

    target5.setOnDragExited(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* mouse moved away, remove the graphical cues */
        target5.setFill(Color.BLACK);
        event.consume();
      }
    });

    target5.setOnDragDropped(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if there is a string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();
        boolean success = false;
        if (db.hasString()&&db.getString().equals("POLLUTION")) {
          target5.setText(db.getString());
          success = true;
        }
        /* let the source know whether the string was successfully
         * transferred and used */
        event.setDropCompleted(success);
        event.consume();
      }
    });

    source5.setOnDragDone(new EventHandler <DragEvent>() {
      public void handle(DragEvent event) {
        /* if the data was successfully moved, clear it */
        if (event.getTransferMode() == TransferMode.MOVE) {
          source5.setText("");
          setTrue(4);
        }
        event.consume();
        if (checkDone())
        {
          root.getChildren().add(btn2);
        }
      }
    });
    Text fact = new Text(40, 420, "Canadians produces approximately 31 million tonnes of garbage each year. However, 75% of it is recyclable. ");
    Text factCont = new Text(40, 450, "This number could be cut down drastically if it wasn't for a lack of effort or knowledge. Each Canadian must");
    Text factCont1 = new Text(50, 480, "do their part to cut down on their garbage production and learn what rightfully belongs in the garbage.");
    Text fact2 = new Text(50, 430, "Canadians average 27 hours a week watching T.V. This is an unhealthy amount for the environment (and");
    Text fact2Cont = new Text(55, 460, "the human body)! This time could be used for outdoor activities that aid our Earth - such as gardening!");
    Text fact3 = new Text(35, 430, "Always be sure to turn off lights when you are not using them! Wasting electricity increases the number of");
    Text fact3Cont = new Text(50, 460, "greenhouse gases in our atmosphere, which is the leading cause of air pollution and climate change.");
    Text fact4 = new Text(45, 430, "House plants cleanse air pollutants throughout your home. This process of absorbing carbon dioxide and ");
    Text fact4Cont = new Text(280, 460, "releasing oxygen is called photosynthesis.");
    Text fact5 = new Text(75, 430, "Many people don't know that electronics plugged in - even if they are NOT on - use electricity.");
    Text fact5Cont = new Text(60, 460, "Unplugging your charger, lamp, or toothbrush when you are not using them can save a lot of energy!");
    Text helpText = new Text(125, 26, "Click on objects around");
    Text helpTextCont = new Text(125, 41, "the room to see how they");
    Text helpTextCont2 = new Text(125, 56, "affect the environment. Then,");
    Text helpTextCont3 = new Text(125, 71, "drag the hidden clues to fill");
    Text helpTextCont4 = new Text(125, 86, "in the secret message below!");
    //bin button
    Button binBtn = new Button("", imageCreate(bin,50,900, 80, 80, true));
    binBtn.setLayoutX(5);
    binBtn.setLayoutY(300);
    binBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(binBtn);

    binBtn.setOnAction(new EventHandler<ActionEvent>() {
                         @Override
                         public void handle(ActionEvent event) {
                           root.getChildren().remove(binBtn);
                           root.getChildren().add(imageCreate (bin2, 0, 300, 90, 90, true));
                           root.getChildren().add(source);
                           root.getChildren().add(rect (0, 386, 900, 115, floor));
                           root.getChildren().add(fact);
                           root.getChildren().add(factCont);
                           root.getChildren().add(factCont1);
                           fact.setFill(Color.WHITE);
                           fact.setFont(Font.font(17));
                           factCont.setFill(Color.WHITE);
                           factCont.setFont(Font.font(17));
                           factCont1.setFill(Color.WHITE);
                           factCont1.setFont(Font.font(17));
                         }
                       }
    );

    //t.v button
    Button tvBtn = new Button("", imageCreate(tv2,55,900, 120, 120, true));
    tvBtn.setLayoutX(750);
    tvBtn.setLayoutY(197);
    tvBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(tvBtn);

    tvBtn.setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                          root.getChildren().remove(tvBtn);
                          root.getChildren().add(imageCreate (tv, 751, 195, 134, 134, true));
                          root.getChildren().add(source2);
                          root.getChildren().add(rect (0, 386, 900, 115, floor));
                          root.getChildren().add(fact2);
                          root.getChildren().add(fact2Cont);
                          fact2.setFill(Color.WHITE);
                          fact2.setFont(Font.font(17));
                          fact2Cont.setFill(Color.WHITE);
                          fact2Cont.setFont(Font.font(17));
                        }
                      }
    );

    //bulb button
    Button bulbBtn = new Button("", imageCreate(bulb,55,900, 140, 140, true));
    bulbBtn.setLayoutX(280);
    bulbBtn.setLayoutY(-30);
    bulbBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(bulbBtn);
    bulbBtn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event) {
                            root.getChildren().remove(bulbBtn);
                            root.getChildren().add(imageCreate (bulb2, 290, -50, 140, 140, true));
                            root.getChildren().add(source3);
                            root.getChildren().add(rect (0, 386, 900, 115, floor));
                            root.getChildren().add(fact3);
                            root.getChildren().add(fact3Cont);
                            fact3.setFill(Color.WHITE);
                            fact3.setFont(Font.font(17));
                            fact3Cont.setFill(Color.WHITE);
                            fact3Cont.setFont(Font.font(17));
                          }
                        }
    );

    //flower button
    Button floBtn = new Button("", imageCreate(flower,55,900, 140, 140, true));
    floBtn.setLayoutX(630);
    floBtn.setLayoutY(242);
    floBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(floBtn);

    floBtn.setOnAction(new EventHandler<ActionEvent>() {
                         @Override
                         public void handle(ActionEvent event) {
                           root.getChildren().remove(floBtn);
                           root.getChildren().add(imageCreate (flower2, 640, 245, 140, 140, true));
                           root.getChildren().add(source4);
                           root.getChildren().add(rect (0, 386, 900, 115, floor));
                           root.getChildren().add(fact4);
                           root.getChildren().add(fact4Cont);
                           fact4.setFill(Color.WHITE);
                           fact4.setFont(Font.font(17));
                           fact4Cont.setFill(Color.WHITE);
                           fact4Cont.setFont(Font.font(17));
                         }
                       }
    );

    //plug button
    Button plugBtn = new Button("", imageCreate(plug,55,900, 140, 140, true));
    plugBtn.setLayoutX(175);
    plugBtn.setLayoutY(242);
    plugBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(plugBtn);

    plugBtn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event) {
                            root.getChildren().remove(plugBtn);
                            root.getChildren().add(source5);
                            root.getChildren().add(rect (0, 386, 900, 115, floor));
                            root.getChildren().add(fact5);
                            root.getChildren().add(fact5Cont);
                            fact5.setFill(Color.WHITE);
                            fact5.setFont(Font.font(17));
                            fact5Cont.setFill(Color.WHITE);
                            fact5Cont.setFont(Font.font(17));
                          }
                        }
    );

    //help button

    ImageView speechBubble = imageCreate (speechBubbleImage, 0, -145, 600, 400, true);
    Button helpBtn = new Button("", imageCreate(help,0,0, 80, 80, true));
    helpBtn.setLayoutX(5);
    helpBtn.setLayoutY(10);
    helpBtn.setStyle("-fx-background-color: #d8e0f1");
    root.getChildren().add(helpBtn);
    helpBtn.setOnMouseEntered (e -> {
      root.getChildren().add(speechBubble);
      root.getChildren().add(helpText);
      root.getChildren().add(helpTextCont);
      root.getChildren().add(helpTextCont2);
      root.getChildren().add(helpTextCont3);
      root.getChildren().add(helpTextCont4);
      helpText.setFill(Color.BLACK);
      helpText.setFont(Font.font(12));
      helpTextCont.setFill(Color.BLACK);
      helpTextCont.setFont(Font.font(12));
      helpTextCont2.setFill(Color.BLACK);
      helpTextCont2.setFont(Font.font(12));
      helpTextCont3.setFill(Color.BLACK);
      helpTextCont3.setFont(Font.font(12));
      helpTextCont4.setFill(Color.BLACK);
      helpTextCont4.setFont(Font.font(12));
    });
    helpBtn.setOnMouseExited (e -> {
      root.getChildren().remove(helpText);
      root.getChildren().remove(helpTextCont);
      root.getChildren().remove(helpTextCont2);
      root.getChildren().remove(helpTextCont3);
      root.getChildren().remove(helpTextCont4);
      root.getChildren().remove(speechBubble);
    });

    final Text text = new Text(87, 555, "A");
    text.setScaleX(2.0);
    text.setScaleY(2.0);
    final Text text2 = new Text(210, 555, "OF   THE");
    text2.setScaleX(2.0);
    text2.setScaleY(2.0);
    final Text text3 = new Text(430, 555, ",");
    text3.setScaleX(2.0);
    text3.setScaleY(2.0);
    final Text text4 = new Text(570, 555, "PART   OF   THE");
    text4.setScaleX(2.0);
    text4.setScaleY(2.0);
    final Text text5 = new Text(850, 555, "!");
    text5.setScaleX(2.0);
    text5.setScaleY(2.0);
    root.getChildren().add(rect (0, 386, 900, 115, floor));
    root.getChildren().add (imageCreate (shelf, 760, 262, 140, 140, true));
    root.getChildren().add (imageCreate (shelf2, 259, 248, 140, 140, true));
    root.getChildren().add (imageCreate (door, 22, 120, 270, 270, true));
    root.getChildren().add(text);
    root.getChildren().add(text2);
    root.getChildren().add(text3);
    root.getChildren().add(text4);
    root.getChildren().add(text5);
    root.getChildren().add(target);
    root.getChildren().add(target2);
    root.getChildren().add(target3);
    root.getChildren().add(target4);
    root.getChildren().add(target5);

    //Timer
    Label timeLabel = new Label("Start");
    timeLabel.setTextFill(Color.web("#0076a3"));
    DateFormat timeFormat = new SimpleDateFormat( "mm:ss" );
    final Timeline timeline = new Timeline(
            new KeyFrame(
                    Duration.millis(500 ),
                    event -> {
                      final long diff = System.nanoTime()/1000000000- Main.startTime;
                      if ( diff < 0 ) {
                        timeLabel.setText( timeFormat.format( 0 ) );
                      } else {
                        timeLabel.setText((int)diff/60+":"+(int)diff%60+" ");
                      }
                    }
            )
    );
    //format and start animation
    timeLabel.setFont(Font.font("Cambria", 32));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeLabel.setLayoutX (780);
    timeLabel.setLayoutY (5);
    root.getChildren().add((timeLabel));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeline.play();

  }

}




