import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.control.Label;
import javafx.animation.Timeline;
import java.text.*;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.animation.Animation;


/** The Room3 class is similar to the first two level but this time instead of identifying the issues,
 * or purposing solutions, it tests the user on what they have been taught in our game.
 * It gives the user a time penalty for a bad answer, and a longer penalty for a very bad answer. As well,
 * it shows which answers were which so they can learn from their mistakes.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 31 2019: Class created by Megan. Image background created externally by Maia and imported.
 *
 * May 31 2019: Edited by Megan so that the LevelRoom class contained methods used by this class.
 *
 * June 2 2019: Megan added timer.
 *
 * June 3 2019: Maia put in all buttons, right answers, wrong answers, and worse answers.
 *
 * June 4 2019: Megan and Maia made the borders around the answers.
 *
 * Approximate time spent working on Room1: 6 hours
 *</pre>
 **/
public class Room3 extends LevelRoom {
  private Group root;
  Scene scene;
  private final Stage stage;
  /**
  *Holds the value of the grey colour the garbage bin uses.
  */
  private final Color greyColour = Color.rgb (119, 119, 119);
  /**
  *Sets up the sink button so that when it is clicked it can be disable (the user can no longer click it).
  */
  private Button sinkBtn;
  /**
  *Sets up the garbage button so that when it is clicked it can be disable (the user can no longer click it).
  */
  private Button garbageBtn;
  /**
  *Sets up the light button so that when it is clicked it can be disable (the user can no longer click it).
  */
  private Button lightBtn;
  /**
  *Sets up the vegetable button so that when it is clicked it can be disable (the user can no longer click it).
  */
  private Button vegBtn;
  /**
  *Sets up the bag button so that when it is clicked it can be disable (the user can no longer click it).
  */
  private Button bagBtn;
  /**
  *Sets up the rectangle in the first position on the left, to border the first answer button.
  */
  private Rectangle rect1;
  /**
  *Sets up the rectangle in the second position in the middle, to border the second answer button.
  */
  private Rectangle rect2;
  /**
  *Sets up the rectangle in the third position on the right, to border the third answer button.
  */
  private Rectangle rect3;
  /**
  *Holds the text that appears if the user makes a mistake (5 seconds for bad mistake, 10 for very bad mistake).
  */
  private Text penalty;

  public Room3 (Stage stage)
  {
    this.stage = stage;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains pictures that were imported. Additionally, a try 
   * and catch to bring the user back to Main Menu. 
   * Also, this method is used to make all of the clues, edit them once clicked, allow for the information at the
   * bottom the be shown, add time to the clock when a penalty occurs, show the user the correct answer for each question
   * and finally calls highScores once finished.
   *
   **/
  public void start() {
    stage.setTitle("Room 3");
    Image image = new Image(("graphics/Rooms3.png"));
    Image help = new Image(("graphics/help.png"));
    Image speechBubbleImage = new Image(("graphics/speechBubble.png"));
    Image kitchenSink = new Image(("graphics/kitchenSink.png"));
    Image plasticBag = new Image(("graphics/PlasticBag.png"));
    Image vegetables = new Image(("Vegetables.png"));
    Image kitchenLight = new Image(("graphics/kitchenLight.png"));
    Image garbage = new Image(("graphics/room3Bin.png"));
    Image counter = new Image(("graphics/kitchenCounter.png"));
    Image window = new Image(("graphics/calAndWindow.png"));
    Image table = new Image(("graphics/table.png"));
    Text whySink = new Text(300, 490, "How can you improve the sink?");
    Text whyGarbage = new Text(260, 490, "How can you improve the garbage bin?");
    Text whyLight = new Text(297, 490, "How can you improve the lights?");
    Text whyVeg = new Text(280, 490, "How can you improve the produce?");
    Text whyBag = new Text(270, 490, "How can you improve the plastic bag?");
    Text instructions = new Text(100, 510, "In this room, choosing the wrong answers will give you time penalties.");
    Text instructions2 = new Text(40, 555, "A BAD answer (yellow) is +5 seconds and a VERY BAD answer (red) is +10 seconds.");
    Image sink1 = new Image(("graphics/sink1.png"));
    Image sink2 = new Image(("graphics/sink2.png"));
    Image sink3 = new Image(("graphics/sink3.png"));
    Image garbage1 = new Image(("graphics/garbage1.png"));
    Image garbage2 = new Image(("graphics/garbage2.png"));
    Image garbage3 = new Image(("graphics/garbage3.png"));
    Image bag1 = new Image(("graphics/bag1.png"));
    Image bag2 = new Image(("graphics/bag2.png"));
    Image bag3 = new Image(("graphics/bag3.png"));
    Image light1 = new Image(("graphics/lights1.png"));
    Image light2 = new Image(("graphics/lights2.png"));
    Image light3 = new Image(("graphics/lights3.png"));
    Image veg1 = new Image(("graphics/veg1.png"));
    Image veg2 = new Image(("graphics/veg2.png"));
    Image veg3 = new Image(("graphics/veg3.png"));
    rect1 = new Rectangle(207, 497, 92, 87);
    rect2 = new Rectangle(407, 497, 92, 87);
    rect3 = new Rectangle(607, 497, 92, 87);

    root = new Group(imageCreate (image, 0, 0, 1350, 900, true));
    scene = new Scene(root, 900, 600);
    //Exit Button
    Button btn = new Button();
    btn.setText("Stop");
    btn.setStyle ("-fx-background-color: #f1a6a6");
    btn.setOnAction(new EventHandler<ActionEvent>() {
                      @Override
                      public void handle(ActionEvent event)
                      {
                        MainMenu m = new MainMenu(stage);
                        m.start();
                        stage.setScene (m.scene);
                      }
                    }
    );
    //Done button
    Button btn2 = new Button();
    btn2.setText("Got it!");
    btn2.setStyle ("-fx-background-color: #ffffff");
    btn2.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event)
                       {
                         HighScores h = new HighScores(stage);
                         h.start();
                         stage.setScene (h.scene);
                       }
                     }
    );
    btn2.setLayoutX(415);
    btn2.setLayoutY(400);
    btn.setLayoutX(850);
    btn.setLayoutY(20);
    //add button
    root.getChildren().add(btn);

    //sink1 Button
    Button sink1Btn = new Button("", imageCreate(sink1,100, 480, 200, 90, true));
    sink1Btn.setLayoutX(200);
    sink1Btn.setLayoutY(492);
    sink1Btn.setStyle("-fx-background-color: #ffffff");
    sink1Btn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event)
                           {
                             enable();
                             root.getChildren().add(rect1);
                             rect1.setStroke(Color.GREEN);
                             rect1.setStrokeWidth(3);
                             rect1.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect2);
                             rect2.setStroke(Color.YELLOW);
                             rect2.setStrokeWidth(3);
                             rect2.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect3);
                             rect3.setStroke(Color.RED);
                             rect3.setStrokeWidth(3);
                             rect3.setFill(Color.TRANSPARENT);

                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );

    //sink2 Button
    Button sink2Btn = new Button("", imageCreate(sink2,100,480, 200, 90, true));
    sink2Btn.setLayoutX(400);
    sink2Btn.setLayoutY(492);
    sink2Btn.setStyle("-fx-background-color: #ffffff");
    sink2Btn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event)
                           {
                             enable();
                             root.getChildren().add(rect1);
                             rect1.setStroke(Color.GREEN);
                             rect1.setStrokeWidth(3);
                             rect1.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect2);
                             rect2.setStroke(Color.YELLOW);
                             rect2.setStrokeWidth(3);
                             rect2.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect3);
                             rect3.setStroke(Color.RED);
                             rect3.setStrokeWidth(3);
                             rect3.setFill(Color.TRANSPARENT);
                             Main.penalty += 5;
                             penalty = new Text(827, 476, "5 seconds \n added to\n your time!");
                             root.getChildren().add(penalty);
                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );

    //sink3 Button
    Button sink3Btn = new Button("", imageCreate(sink3,100,480, 200, 90, true));
    sink3Btn.setLayoutX(600);
    sink3Btn.setLayoutY(492);
    sink3Btn.setStyle("-fx-background-color: #ffffff");
    sink3Btn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event)
                           {
                             enable();
                             root.getChildren().add(rect1);
                             rect1.setStroke(Color.GREEN);
                             rect1.setStrokeWidth(3);
                             rect1.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect2);
                             rect2.setStroke(Color.YELLOW);
                             rect2.setStrokeWidth(3);
                             rect2.setFill(Color.TRANSPARENT);
                             root.getChildren().add(rect3);
                             rect3.setStroke(Color.RED);
                             rect3.setStrokeWidth(3);
                             rect3.setFill(Color.TRANSPARENT);
                             Main.penalty += 10;
                             penalty = new Text(827, 476, "10 seconds \n added to\n your time!");
                             root.getChildren().add(penalty);
                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );

    //bag 1 Button
    Button bag1Btn = new Button("", imageCreate(bag1,100,500, 195, 90, true));
    bag1Btn.setLayoutX(200);
    bag1Btn.setLayoutY(494);
    bag1Btn.setStyle("-fx-background-color: #ffffff");
    bag1Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            enable();
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.RED);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.YELLOW);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            Main.penalty += 10;
                            penalty = new Text(827, 476, "10 seconds \n added to\n your time!");
                            root.getChildren().add(penalty);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //bag 2 Button
    Button bag2Btn = new Button("", imageCreate(bag2,100,500, 195, 90, true));
    bag2Btn.setLayoutX(400);
    bag2Btn.setLayoutY(494);
    bag2Btn.setStyle("-fx-background-color: #ffffff");
    bag2Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.RED);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.YELLOW);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            enable();
                            Main.penalty += 5;
                            penalty = new Text(827, 476, "5 seconds \n added to\n your time!");
                            root.getChildren().add(penalty);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //bag 3 Button
    Button bag3Btn = new Button("", imageCreate(bag3,100,500, 195, 90, true));
    bag3Btn.setLayoutX(600);
    bag3Btn.setLayoutY(494);
    bag3Btn.setStyle("-fx-background-color: #ffffff");
    bag3Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            enable();
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.RED);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.YELLOW);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );


    //garbage 1 Button
    Button garbage1Btn = new Button("", imageCreate(garbage1,100,500, 195, 90, true));
    garbage1Btn.setLayoutX(200);
    garbage1Btn.setLayoutY(492);
    garbage1Btn.setStyle("-fx-background-color: #ffffff");
    garbage1Btn.setOnAction(new EventHandler<ActionEvent>() {
                              @Override
                              public void handle(ActionEvent event)
                              {
                                enable();
                                root.getChildren().add(rect1);
                                rect1.setStroke(Color.RED);
                                rect1.setStrokeWidth(3);
                                rect1.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect2);
                                rect2.setStroke(Color.GREEN);
                                rect2.setStrokeWidth(3);
                                rect2.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect3);
                                rect3.setStroke(Color.YELLOW);
                                rect3.setStrokeWidth(3);
                                rect3.setFill(Color.TRANSPARENT);
                                Main.penalty += 10;
                                penalty = new Text(827, 476, "10 seconds \n added to\n your time!");
                                root.getChildren().add(penalty);
                                if (checkDone())
                                {
                                  root.getChildren().add(btn2);
                                }
                              }
                            }
    );

    //garbage 2 Button
    Button garbage2Btn = new Button("", imageCreate(garbage2,100,500, 195, 90, true));
    garbage2Btn.setLayoutX(400);
    garbage2Btn.setLayoutY(492);
    garbage2Btn.setStyle("-fx-background-color: #ffffff");
    garbage2Btn.setOnAction(new EventHandler<ActionEvent>() {
                              @Override
                              public void handle(ActionEvent event)
                              {
                                enable();
                                root.getChildren().add(rect1);
                                rect1.setStroke(Color.RED);
                                rect1.setStrokeWidth(3);
                                rect1.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect2);
                                rect2.setStroke(Color.GREEN);
                                rect2.setStrokeWidth(3);
                                rect2.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect3);
                                rect3.setStroke(Color.YELLOW);
                                rect3.setStrokeWidth(3);
                                rect3.setFill(Color.TRANSPARENT);

                                if (checkDone())
                                {
                                  root.getChildren().add(btn2);
                                }
                              }
                            }
    );

    //garbage 3 Button
    Button garbage3Btn = new Button("", imageCreate(garbage3,100,500, 195, 90, true));
    garbage3Btn.setLayoutX(600);
    garbage3Btn.setLayoutY(492);
    garbage3Btn.setStyle("-fx-background-color: #ffffff");
    garbage3Btn.setOnAction(new EventHandler<ActionEvent>() {
                              @Override
                              public void handle(ActionEvent event)
                              {
                                enable();
                                root.getChildren().add(rect1);
                                rect1.setStroke(Color.RED);
                                rect1.setStrokeWidth(3);
                                rect1.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect2);
                                rect2.setStroke(Color.GREEN);
                                rect2.setStrokeWidth(3);
                                rect2.setFill(Color.TRANSPARENT);
                                root.getChildren().add(rect3);
                                rect3.setStroke(Color.YELLOW);
                                rect3.setStrokeWidth(3);
                                rect3.setFill(Color.TRANSPARENT);
                                Main.penalty += 5;
                                penalty = new Text(827, 476, "5 seconds \n added to\n your time!");
                                root.getChildren().add(penalty);
                                if (checkDone())
                                {
                                  root.getChildren().add(btn2);
                                }
                              }
                            }
    );


    //veg 1 Button
    Button veg1Btn = new Button("", imageCreate(veg1,100,500, 195, 90, true));
    veg1Btn.setLayoutX(200);
    veg1Btn.setLayoutY(492);
    veg1Btn.setStyle("-fx-background-color: #ffffff");
    veg1Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            enable();
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.YELLOW);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.RED);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            Main.penalty += 5;
                            penalty = new Text(827, 476, "5 seconds \n added to\n your time!");
                            root.getChildren().add(penalty);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //veg 2 Button
    Button veg2Btn = new Button("", imageCreate(veg2,100,500, 195, 90, true));
    veg2Btn.setLayoutX(400);
    veg2Btn.setLayoutY(492);
    veg2Btn.setStyle("-fx-background-color: #ffffff");
    veg2Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            enable();
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.YELLOW);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.RED);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            Main.penalty += 10;
                            penalty = new Text(827, 476, "10 seconds \n added to\n your time!");
                            root.getChildren().add(penalty);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //veg 3 Button
    Button veg3Btn = new Button("", imageCreate(veg3,100,500, 195, 90, true));
    veg3Btn.setLayoutX(600);
    veg3Btn.setLayoutY(492);
    veg3Btn.setStyle("-fx-background-color: #ffffff");
    veg3Btn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event)
                          {
                            enable();
                            root.getChildren().add(rect1);
                            rect1.setStroke(Color.YELLOW);
                            rect1.setStrokeWidth(3);
                            rect1.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect2);
                            rect2.setStroke(Color.RED);
                            rect2.setStrokeWidth(3);
                            rect2.setFill(Color.TRANSPARENT);
                            root.getChildren().add(rect3);
                            rect3.setStroke(Color.GREEN);
                            rect3.setStrokeWidth(3);
                            rect3.setFill(Color.TRANSPARENT);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //light 1 Button
    Button light1Btn = new Button("", imageCreate(light1,98,498, 195, 90, true));
    light1Btn.setLayoutX(200);
    light1Btn.setLayoutY(494);
    light1Btn.setStyle("-fx-background-color: #ffffff");
    light1Btn.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event)
                            {
                              enable();
                              root.getChildren().add(rect1);
                              rect1.setStroke(Color.YELLOW);
                              rect1.setStrokeWidth(3);
                              rect1.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect2);
                              rect2.setStroke(Color.RED);
                              rect2.setStrokeWidth(3);
                              rect2.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect3);
                              rect3.setStroke(Color.GREEN);
                              rect3.setStrokeWidth(3);
                              rect3.setFill(Color.TRANSPARENT);
                              Main.penalty += 5;
                              penalty = new Text(827, 476, "5 seconds \n added to\n your time!");
                              root.getChildren().add(penalty);
                              if (checkDone())
                              {
                                root.getChildren().add(btn2);
                              }
                            }
                          }
    );

    //light 2 Button
    Button light2Btn = new Button("", imageCreate(light2,100,500, 195, 90, true));
    light2Btn.setLayoutX(400);
    light2Btn.setLayoutY(494);
    light2Btn.setStyle("-fx-background-color: #ffffff");
    light2Btn.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event)
                            {
                              enable();
                              root.getChildren().add(rect1);
                              rect1.setStroke(Color.YELLOW);
                              rect1.setStrokeWidth(3);
                              rect1.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect2);
                              rect2.setStroke(Color.RED);
                              rect2.setStrokeWidth(3);
                              rect2.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect3);
                              rect3.setStroke(Color.GREEN);
                              rect3.setStrokeWidth(3);
                              rect3.setFill(Color.TRANSPARENT);
                              Main.penalty += 10;
                              penalty = new Text(827, 476, "10 seconds \n added to\n your time!");
                              root.getChildren().add(penalty);
                              if (checkDone())
                              {
                                root.getChildren().add(btn2);
                              }
                            }
                          }
    );

    //light 3 Button
    Button light3Btn = new Button("", imageCreate(light3,100,500, 195, 90, true));
    light3Btn.setLayoutX(600);
    light3Btn.setLayoutY(493);
    light3Btn.setStyle("-fx-background-color: #ffffff");
    light3Btn.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event)
                            {
                              enable();
                              root.getChildren().add(rect1);
                              rect1.setStroke(Color.YELLOW);
                              rect1.setStrokeWidth(3);
                              rect1.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect2);
                              rect2.setStroke(Color.RED);
                              rect2.setStrokeWidth(3);
                              rect2.setFill(Color.TRANSPARENT);
                              root.getChildren().add(rect3);
                              rect3.setStroke(Color.GREEN);
                              rect3.setStrokeWidth(3);
                              rect3.setFill(Color.TRANSPARENT);
                              if (checkDone())
                              {
                                root.getChildren().add(btn2);
                              }
                            }
                          }
    );

    //sink button
    sinkBtn = new Button("", imageCreate(kitchenSink,0,0, 170, 170, true));
    sinkBtn.setLayoutX(20);
    sinkBtn.setLayoutY(110);
    sinkBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(sinkBtn);

    sinkBtn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event) {
                            disable();
                            root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
                            root.getChildren().add(whySink);
                            whySink.setFill(Color.BLACK);
                            whySink.setFont(Font.font(22));
                            root.getChildren().add(sink1Btn);
                            root.getChildren().add(sink2Btn);
                            root.getChildren().add(sink3Btn);
                            root.getChildren ().add(rect(0, 590, 900, 10, Color.web("rgb(145, 191, 223)")));
                            setTrue(0);
                          }
                        }
    );

    //bag button
    bagBtn = new Button("", imageCreate(plasticBag,0,0, 80, 80, true));
    bagBtn.setLayoutX(220);
    bagBtn.setLayoutY(170);
    bagBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(bagBtn);

    bagBtn.setOnAction(new EventHandler<ActionEvent>() {
                         @Override
                         public void handle(ActionEvent event) {
                           disable();
                           root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
                           root.getChildren().add(whyBag);
                           whyBag.setFill(Color.BLACK);
                           whyBag.setFont(Font.font(22));
                           root.getChildren().add(bag1Btn);
                           root.getChildren().add(bag2Btn);
                           root.getChildren().add(bag3Btn);
                           root.getChildren ().add(rect(0, 590, 900, 10, Color.web("rgb(145, 191, 223)")));
                           setTrue(1);
                         }
                       }
    );


    //light button
    lightBtn = new Button("", imageCreate(kitchenLight,0,0, 170, 170, true));
    lightBtn.setLayoutX(460);
    lightBtn.setLayoutY(-10);
    lightBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(lightBtn);
    lightBtn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event) {
                             disable();
                             root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
                             root.getChildren().add(whyLight);
                             whyLight.setFill(Color.BLACK);
                             whyLight.setFont(Font.font(22));
                             root.getChildren().add(light1Btn);
                             root.getChildren().add(light2Btn);
                             root.getChildren().add(light3Btn);
                             root.getChildren ().add(rect(0, 590, 900, 10, Color.web("rgb(145, 191, 223)")));
                             setTrue(2);
                           }
                         }
    );

    //garbage button
    garbageBtn = new Button("", imageCreate(garbage,0,0, 100, 100, true));
    garbageBtn.setLayoutX(359);
    garbageBtn.setLayoutY(271);
    garbageBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(garbageBtn);
    garbageBtn.setOnAction(new EventHandler<ActionEvent>() {
                             @Override
                             public void handle(ActionEvent event) {
                               disable();
                               root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
                               root.getChildren().add(whyGarbage);
                               whyGarbage.setFill(Color.BLACK);
                               whyGarbage.setFont(Font.font(22));
                               root.getChildren().add(garbage1Btn);
                               root.getChildren().add(garbage2Btn);
                               root.getChildren().add(garbage3Btn);
                               root.getChildren ().add(rect(0, 590, 900, 10, Color.web("rgb(145, 191, 223)")));
                               setTrue(3);
                             }
                           }
    );

    //vegetable button
    vegBtn = new Button("", imageCreate(vegetables,0,0, 100, 100, true));
    vegBtn.setLayoutX(542);
    vegBtn.setLayoutY(207);
    vegBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(vegBtn);
    vegBtn.setOnAction(new EventHandler<ActionEvent>() {
                         @Override
                         public void handle(ActionEvent event) {
                           disable();
                           root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
                           root.getChildren().add(whyVeg);
                           whyVeg.setFill(Color.BLACK);
                           whyVeg.setFont(Font.font(22));
                           root.getChildren().add(veg1Btn);
                           root.getChildren().add(veg2Btn);
                           root.getChildren().add(veg3Btn);
                           root.getChildren ().add(rect(0, 590, 900, 10, Color.web("rgb(145, 191, 223)")));
                           setTrue(4);
                         }
                       }
    );

    //help button
    Text helpText = new Text(123, 26, "There are no obvious issues");
    Text helpTextCont = new Text(123, 41, "here. However, there are");
    Text helpTextCont2 = new Text(123, 56, "areas of improvement. Click");
    Text helpTextCont3 = new Text(123, 71, "on objects and pick the");
    Text helpTextCont4 = new Text(123, 86, "corresponding 'green' option!");
    ImageView speechBubble = imageCreate (speechBubbleImage, 0, -145, 600, 400, true);
    Button helpBtn = new Button("", imageCreate(help,0,0, 80, 80, true));
    helpBtn.setLayoutX(5);
    helpBtn.setLayoutY(10);
    helpBtn.setStyle("-fx-background-color: #c2f0c9");
    root.getChildren().add(helpBtn);
    helpBtn.setOnMouseEntered (e -> {
      root.getChildren().add(speechBubble);
      root.getChildren().add(helpText);
      root.getChildren().add(helpTextCont);
      root.getChildren().add(helpTextCont2);
      root.getChildren().add(helpTextCont3);
      root.getChildren().add(helpTextCont4);
      helpText.setFill(Color.BLACK);
      helpText.setFont(Font.font(12));
      helpTextCont.setFill(Color.BLACK);
      helpTextCont.setFont(Font.font(12));
      helpTextCont2.setFill(Color.BLACK);
      helpTextCont2.setFont(Font.font(12));
      helpTextCont3.setFill(Color.BLACK);
      helpTextCont3.setFont(Font.font(12));
      helpTextCont4.setFill(Color.BLACK);
      helpTextCont4.setFont(Font.font(12));
    });
    helpBtn.setOnMouseExited (e -> {
      root.getChildren().remove(helpText);
      root.getChildren().remove(helpTextCont);
      root.getChildren().remove(helpTextCont2);
      root.getChildren().remove(helpTextCont3);
      root.getChildren().remove(helpTextCont4);
      root.getChildren().remove(speechBubble);
    });
    root.getChildren().add(imageCreate (counter, 0, 102, 370, 370, true));
    root.getChildren().add (imageCreate (window, 133, -37, 280, 280, true));
    root.getChildren().add (imageCreate (table, 512, 247, 187, 187, true));
    root.getChildren ().add(rect(0, 450, 900, 150, Color.web("rgb(145, 191, 223)")));
    root.getChildren (). add (rect (10, 460, 880, 130, Color.WHITE));
    root.getChildren().add(rect(374, 371, 69, 12, greyColour)); //the rect under the garbage bin
    root.getChildren().add(instructions);
    root.getChildren().add(instructions2);
    instructions.setFill(Color.BLACK);
    instructions.setFont(Font.font(22));
    instructions2.setFill(Color.BLACK);
    instructions2.setFont(Font.font(22));
    //Timer
    Label timeLabel = new Label("");
    timeLabel.setTextFill(Color.web("#0076a3"));
    DateFormat timeFormat = new SimpleDateFormat( "HH:mm:ss" );
    final Timeline timeline = new Timeline(
            new KeyFrame(
                    Duration.millis(500 ),
                    event -> {
                      final long diff = System.nanoTime()/1000000000- Main.startTime+ Main.penalty;
                      if ( diff < 0 ) {
                        timeLabel.setText( timeFormat.format( 0 ) );
                      } else {
                        timeLabel.setText((int)diff/60+":"+(int)diff%60+" ");
                      }
                    }
            )
    );
    //format and start animation
    timeLabel.setFont(Font.font("Cambria", 32));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeLabel.setLayoutX (780);
    timeLabel.setLayoutY (5);
    root.getChildren().add((timeLabel));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeline.play();
  }

  /**
   * the method enable allows the buttons to work again after the user has clicked an option for an answer.
   * If an object has already been clicked and answer though, it will not enable it. 
   **/
  private void enable()
  {
    if (!checkTrue (0))
      sinkBtn.setDisable (false);
    if (!checkTrue (1))
      bagBtn.setDisable (false);
    if (!checkTrue (3))
    {
      root.getChildren().add(rect(374, 371, 69, 12, greyColour)); //the rect under the garbage bin
      garbageBtn.setDisable (false);
    }
    if (!checkTrue (2))
      lightBtn.setDisable (false);
    if (!checkTrue (4))
      vegBtn.setDisable (false);
  }
  /**
   * the method disable stops the buttons from working once another button has been clicked.
   **/
  private void disable()
  {
    sinkBtn.setDisable (true);
    bagBtn.setDisable (true);
    garbageBtn.setDisable (true);
    lightBtn.setDisable (true);
    vegBtn.setDisable (true);
    root.getChildren().add(rect(374, 371, 69, 12, Color.web("rgb(164, 192, 168)"))); //the rect under the garbage bin
    root.getChildren().remove(rect1);
    root.getChildren().remove(rect2);
    root.getChildren().remove(rect3);
    root.getChildren().remove (penalty);
  }
}




