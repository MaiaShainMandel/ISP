import javafx.animation.PathTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.animation.FadeTransition;
import static javafx.animation.PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT;

/** The Introduction class was created to make the user smile with a fun and pleasing animation that is
 * relevant to our game. It starts with our logo that fades in and out, and then a short loading screen.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 31 2019: Class created by Megan. Logo fade in and out completed.
 *
 * June 2 2019: Edited by megan, added in the key loading animation.
 *
 * June 3 2019: Edited by Maia, made the key go around once less, and slowed down the speed.
 * 
 * Approximate time spent working on Introduction:  5 hours
 *</pre>
 */
public class Introduction
{
    private HBox root;
    Scene scene;
    private final Stage stage;

    public Introduction (Stage stage)
    {
        this.stage = stage;
    }
    /** Start is a public method that sets the screen up, creating buttons, background, and text for the
     * page to be based around. It contains pictures that were imported, and the animation. Additionally, a try
     * and catch to lead the program to the Main Menu after the loading screen finished.
     *
     **/
    public void start() {
        // Create the logo
        Image logo = new Image ("graphics/logo.png");
        ImageView logoView = new ImageView(logo);
        //Setting the position of the image
        logoView.setX(600);
        logoView.setY(100);
        logoView.setFitHeight(400);
        logoView.setFitWidth (400);

        // Create the images
        Image earth = new Image(("graphics/LoadingPage.png"));
        Image key = new Image(("graphics/key.png"));
        //Setting the position of the background
        ImageView imageView = new ImageView (earth);
        imageView.setX(100);
        imageView.setY(0);
        //setting the fit height and width of the image view
        imageView.setFitHeight(100);
        imageView.setFitWidth(900);
        //Setting the preserve ratio of the image view
        imageView.setPreserveRatio(true);
        //Setting the position of the background
        ImageView imageView2 = new ImageView (key);
        imageView2.setX(100);
        imageView2.setY(50);
        //setting the fit height and width of the image view
        imageView2.setFitHeight(100);
        imageView2.setFitWidth(900);
        //Setting the preserve ratio of the image view
        imageView2.setPreserveRatio(true);

        // Create the path
        Circle path = new Circle(250);
        path.setCenterX(130);
        path.setCenterY (300);
        path.setFill(null);
        path.setStroke(Color.BLACK);

        // Create the HBox
        root = new HBox(logoView);
        // Set the Style-properties of the HBox
        root.setStyle("-fx-padding: 0;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 0;" +
                "-fx-border-insets: 95 0 0 250;" +
                "-fx-border-radius: 0;" +
                "-fx-border-color: black;"+
                "-fx-fill-color: black");

        // Create the Scene
        scene = new Scene(root, 900, 600, Color.BLACK);
        // Add the Scene to the Stage
        stage.setScene(scene);
        // Set the Title of the Stage
        stage.setTitle("Escape Extinction");
        // Display the Stage
        stage.show();

        // Set up a fade-in and fade-out animation for the rectangle
        FadeTransition trans = new FadeTransition(Duration.seconds(4), logoView);
        trans.setFromValue(.0);
        trans.setToValue(100);
        // Let the animation run forever
        trans.setCycleCount(2);
        // Reverse direction on alternating cycles
        trans.setAutoReverse(true);
        // Play the Animation
        trans.play();

        trans.setOnFinished (e-> {
            BackgroundImage myBI= new BackgroundImage(earth, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,BackgroundSize.DEFAULT);
            root.setBackground(new Background(myBI));
            root.getChildren().addAll (imageView2);
            // Set the Size of the VBox
            root.setPrefSize(900, 600);
            // Set the Style-properties of the VBox
            root.setStyle("-fx-padding: 10;" +
                    "-fx-border-style: solid inside;" +
                    "-fx-border-width: 0;" +
                    "-fx-border-insets: 0;" +
                    "-fx-border-radius: 5;" +
                    "-fx-border-color: white;");

            // Set up a Scale Transition
            ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(1));
            scaleTransition.setFromX(1.0);
            scaleTransition.setToX(2.0);
            scaleTransition.setFromY(1.0);
            scaleTransition.setToY(2.0);
            // Let the animation run forever
            scaleTransition.setCycleCount(2);
            // Reverse direction on alternating cycles
            scaleTransition.setAutoReverse(true);

            // Set up a Path Transition
            PathTransition pathTransition = new PathTransition(Duration.seconds(2), path);
            pathTransition.setOrientation(ORTHOGONAL_TO_TANGENT);
            // Create a sequential transition
            SequentialTransition sequTransition = new SequentialTransition();
            // Rectangle is the node for all animations
            sequTransition.setNode(imageView2);
            trans.setNode(logoView);
            // Add animations to the list
            sequTransition.getChildren().addAll(scaleTransition,pathTransition);
            // Let the animation run forever
            sequTransition.setCycleCount(2);
            // Play the Animation
            sequTransition.play();
            sequTransition.setOnFinished ( f-> {
                MainMenu m = new MainMenu(stage);
                m.start();
                stage.setScene (m.scene);
            });
        });


    }
}