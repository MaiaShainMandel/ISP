import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.*;
import javafx.scene.control.TextField;
import java.lang.Integer;
import javafx.scene.text.FontWeight;

/** The HighScores class is the class that writes and reads to a high score file, and outputs it to the user.
 * Once finished playing, the user gets to input their name to potentially be saved onto the highscores.
 * If the user's score after playing the game is less than the top five previous scores, than the user
 * will make it onto the leaderboard. Otherwise, the score will just be outputted and the leader board will display
 * only the top five scores. 
 * 
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 28 2019: Class created by Megan. No work progress completed.
 *
 * June 2 2019: Edited by Megan, made the basic layout of this class.
 *
 * June 4 2019: Edited by Maia, changed so that score of user would appear on the side as well.
 * Also, top 5 scores only outputted. Changed minor preferences such as background colour.
 *
 * June 5 2019: Edited by Megan, minor preferences. Button colour and worded altered.
 *
 * Approximate time spent working on HighScores: 4 hours 
 *</pre>
 */
public class HighScores extends LevelRoom {
  
  private Group root;
  Scene scene;
  private final Stage stage;
  /** This String array holds all the scores as a string for the leader board.
    */
  private final String [] scores = {" ", " ", " ", " ", " "};
   /**This string array holds all the names of the people that have scores on leader board.
    */
  private final String [] scoresNames = {" ", " ", " ", " ", " "};
   /** Holds all the scores as an int.
    */
  private int [] allScores= {0, 0, 0, 0, 0};
   /** Holds all the names of all players.
    */
  private String [] allNames= {"EMPTY ", "EMPTY ", "EMPTY ", "EMPTY ", "EMPTY "};
   /** This String array holds all the scores as a string for the leader board.
    */
  private final File file = new File(System.getProperty("user.home")+"/Desktop/Highscores.txt");
   /** Holds the username of the player that played most recently before adding to array.
    */
  private String userName;
  
  public HighScores (Stage stage) 
  {
    this.stage = stage;
    
  }
  /**
   * Start is a public method that sets the screen up, creating buttons and text for the 
   * page to be based around. It contains try methods that will return the user to the Main Menu
   * if the Quit button is pressed, as well as writes to the high scores file. 
   *
   **/
  public void start() {
    Button btn = new Button();
    Text [] places = new Text [5];
    Text [] places2 = new Text [5];
    Image image = new Image(("graphics/HighScores.png"));
    ImageView imageView = imageCreate (image, 0, 0, 1000, 900, true);
    btn.setLayoutX(850);
    btn.setLayoutY(20);
    btn.setText("Quit");
    btn.setStyle("-fx-background-color:#d2c7ff");
    btn.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
          MainMenu m = new MainMenu(stage);
          m.start();
          stage.setScene (m.scene);
      }
    }
    );
    root = new Group(imageView);
    scene = new Scene(root, 900, 600);
    setTimes();
    TextField textField = new TextField();
    textField.setLayoutX (390);
    textField.setLayoutY (190);
    textField.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
    textField.setStyle("-fx-background-color: #ffffff");
    root.getChildren().add(textField);
    Button  btnTest = new Button("Enter");
    btnTest.setLayoutX (620);
    btnTest.setLayoutY (190);
    btnTest.setMaxSize(100, 200);
    btnTest.setStyle ("-fx-background-color: #f6e0ff");
    btnTest.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        btnTest.setDisable(true);
        userName = textField.getText();
        writeScore();
        readFile();
        sortFile(); 
        for (int i = 0; i<5; i++)
        {
          places [i] = new Text(160, 370+50*i,  scores[i]);
          places2 [i] = new Text(45, 370+50*i,  scoresNames[i]);
          places[i].setFont(Font.font("Verdana", FontWeight.BOLD, 20));
          places2[i].setFont(Font.font("Verdana", FontWeight.BOLD, 20));
          root.getChildren().add(places[i]);
          root.getChildren().add (places2[i]);
        }
        Text message = new Text (620, 420, "Your Score: ");
        message.setFont(Font.font("Verdana", FontWeight.BOLD, 25));
        root.getChildren().add(message);
        Text yourScore = new Text (640, 490, (int)Main.finalTime/60+":"+(int)Main.finalTime%60+"");
        yourScore.setFont(Font.font("Verdana", FontWeight.BOLD, 40));
        root.getChildren().add(yourScore);
        
      }
    }
    );
    root.getChildren().add(btnTest);
    root.getChildren().add(btn);
  }
  /**
   * readFile reads all the high scores and the score that the user just accomplished. 
   * If the current score is less than any of the previous top five, it will show up in the 
   * leader board in the correct position.
   **/
  private void readFile()
  {
    String inputStr = "";
    int lineCount = 0;
    BufferedReader input;
    try
    {
      if (file.exists ()) //check if file exists
      {
        input = new BufferedReader (new FileReader (file)); //set BufferedReader
        while (inputStr!=null)
        {
          inputStr = input.readLine (); //read user name
          if (inputStr == null)
            break;
          lineCount++;
        }
      }
    }
    catch (IOException ignored)
    {
    }
    allScores = new int [lineCount /2];
    allNames = new String [lineCount /2];
    
    try
    {
      if (file.exists ()) //check if file exists
      {
        input = new BufferedReader (new FileReader (file)); //set BufferedReader
        for (int i =0; i < lineCount/2; i++)
        {
          allNames [i]= input.readLine (); //read user name
          allScores[i] = Integer.parseInt (input.readLine());
        }
      }
    }
    catch (IOException ignored)
    {
    }
  }
  
  
  
  
  private void sortFile()
  {
    for (int i = 0; i < allScores.length-1; i++) 
      for (int j = 0; j < allScores.length-i-1; j++) 
      if (allScores[j] > allScores[j+1]) 
    { 
      String temp1 = allNames[j];
      int temp2 = allScores[j];
      allNames[j] = allNames[j+1];
      allScores[j] = allScores[j+1];
      allNames[j+1] = temp1;
      allScores[j+1] = temp2;
    } 
    for (int i = 0; i < allScores.length&& i<5; i++)
    {
      scores[i] = allScores[i] /60+":"+ allScores[i] %60;
      scoresNames[i] = allNames[i]+ "";
    }
  }
  
  private void writeScore()
  {
    PrintWriter output;
    try
    {
      output = new PrintWriter (new FileWriter (file, true)); //save name and balance to file
      // write data to the file
      output.println (userName);
      output.println (Main.finalTime);
      // close the stream
      output.close ();
    }
    catch (IOException ignored)
    {
    } 
  }
  
  private void setTimes()
  {
    Main.endTime = System.nanoTime()/1000000000;
    Main.finalTime = (Main.endTime - Main.startTime + Main.penalty);
  }
  
}
