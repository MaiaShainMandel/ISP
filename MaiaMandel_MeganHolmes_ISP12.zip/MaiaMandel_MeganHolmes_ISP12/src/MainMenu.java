import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.animation.PathTransition;
import javafx.util.Duration;

/** The Main Menu class controls the outcomes of the program. It is the directory, the point that allows the user
 * to reach most parts of the game. It is the control center. By going to How To Play, they can learn the game.
 * By pressing Start, they can play. And the only point at which they can exit is by clicking Quit. There is also
 * a small cute animation. A cape that the key - game character - wears that blows in the wind.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 15 2019: Class created by Maia. Buttons put in.
 *
 * May 16 2019: Buttons redesigned and put in by Megan.
 *
 * May 18: Background made by Megan and Maia together.
 *
 * May 22 2019: Edited by Megan, finished animation of main menu.
 *
 * Approximate time spent working on MainMenu: 4 hours 
 *</pre>
 **/
public class MainMenu {
  /**
  *Holds the basic background colour used in many shapes around the room
  */
  private final Color background = Color.rgb (178, 217, 246);
  private Group root;
  Scene scene;
  private final Stage stage;

  public MainMenu(Stage stage) {
    this.stage = stage;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains pictures that were imported, and the animation. Additionally, a try 
   * and catch to lead the program to the instructions page, start the game, or exit the program.
   *
   **/
  public void start() {
    //create images
    Image back = new Image(("graphics/mainBack.png"));
    Image start = new Image(("graphics/Start.png"));
    Image selectedStart = new Image(("graphics/Start2.png"));
    Image quit = new Image(("graphics/Quit.png"));
    Image selectedQuit = new Image(("graphics/SelectedQuit.png"));
    Image howTo = new Image(("graphics/HowToPlay.png"));
    Image selectedHowTo = new Image(("graphics/SelectedHowTo.png"));
    Image keyMan = new Image(("graphics/KeyMan.png"));
    ImageView imageView = new ImageView(back);
    //Setting the position of the background 
    imageView.setX(0);
    imageView.setY(0);
    //setting the fit height and width of the image view 
    imageView.setFitHeight(1000);
    imageView.setFitWidth(900);
    //Setting the preserve ratio of the image view 
    imageView.setPreserveRatio(true);
    // Create the cape ripple
    ImageView shape = new ImageView (new Image (("graphics/shape.png")));
    // Create the Path
    Line path = new Line();
    path.setStartX(170.0f);
    path.setStartY(225.0f);
    path.setEndX(1000.0f);
    path.setEndY(225.0f);
    path.setFill(null);
    path.setStroke( Color.web("rgb(255, 87, 87)"));

    //create group
    root = new Group(imageView, shape, path);
    //create scene
    scene = new Scene(root, 900, 600, background);
    Button btn = new Button("", imageCreate(start,55,900, 140, 140, true));
    btn.setLayoutX(455);
    btn.setLayoutY(382);
    btn.setStyle("-fx-background-color: #d2c7ff");
    root.getChildren().add(btn);
    Button btnP = new Button("", imageCreate(selectedStart,55,900, 140, 140, true));
    btnP.setLayoutX(455);
    btnP.setLayoutY(382);
    btnP.setStyle("-fx-background-color: #d2c7ff");
    Button btn2 = new Button("", imageCreate (howTo, 0, 0, 147, 147, true));
    btn2.setLayoutX (600);
    btn2.setLayoutY (472);
    btn2.setScaleX(2.1);
    btn2.setScaleY(2.1);
    btn2.setStyle("-fx-background-color: #d2c7ff");
    root.getChildren().add(btn2);
    Button btnH = new Button("", imageCreate(selectedHowTo,55,900, 147, 147, true));
    btnH.setLayoutX(600);
    btnH.setLayoutY(472);
    btnH.setScaleX(2.1);
    btnH.setScaleY(2.1);
    btnH.setStyle("-fx-background-color: #d2c7ff");
    Button btn3 = new Button("", imageCreate(quit,55,900, 115, 115, true));
    btn3.setLayoutX(765);
    btn3.setLayoutY(522);
    btn3.setStyle("-fx-background-color: #d2c7ff");
    root.getChildren().add(btn3);
    Button btnQ = new Button("", imageCreate(selectedQuit,55,900, 115, 115, true));
    btnQ.setLayoutX(765);
    btnQ.setLayoutY(522);
    btnQ.setStyle("-fx-background-color: #d2c7ff");
    btn.setOnMouseEntered(e -> {
      root.getChildren().add(btnP);
      root.getChildren().remove(btn);
    });
    btnP.setOnMouseExited(e ->{
      root.getChildren().add(btn);
      root.getChildren().remove(btnP);
    });
    btn3.setOnMouseEntered(e -> {
      root.getChildren().add(btnQ);
      root.getChildren().remove(btn3);
    });
    btnQ.setOnMouseExited(e ->{
      root.getChildren().add(btn3);
      root.getChildren().remove(btnQ);
    });
    btn2.setOnMouseEntered(e -> {
      root.getChildren().add(btnH);
      root.getChildren().remove(btn2);
    });
    btnH.setOnMouseExited(e ->{
      root.getChildren().add(btn2);
      root.getChildren().remove(btnH);
    });
    btnP.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event) {
                         Room1 r1 = new Room1(stage);
                         r1.start();
                         stage.setScene (r1.scene);
                       }
                     }
    );
    btnH.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event) {
                         Instructions instr = new Instructions(stage);
                         instr.start();
                         stage.setScene (instr.scene);
                       }
                     }
    );

    btnQ.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event) {
                         stage.close();
                       }
                     }
    );
    // Set up a Path Transition for the Rectangle
    PathTransition trans = new PathTransition(Duration.seconds(2), path, shape);
    trans.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
    // Let the animation run forever
    trans.setCycleCount(PathTransition.INDEFINITE);
    // Reverse direction on alternating cycles
    trans.setAutoReverse(false);
    // Play the Animation
    trans.play();
    //Key man
    ImageView key = imageCreate (keyMan, 0, 0, 900, 900, true);
    //rectangle to finish cape
    Rectangle rect = new Rectangle (200, 220, 800, 10);
    rect.setFill (Color.web("rgb(255, 46, 0)"));
    root.getChildren().add(rect);
    root.getChildren().add(key);
  }
  /**
   * ImageView is a useful method that alters an imported image using
   * the parameters - making altering an imported image much easier and efficient. 
   *
   * @param i: chooses image
   * @param x: changes x coordinate value
   * @param y: changes y coordinate value
   * @param h: changes pic height value
   * @param w: changes pic width value
   * @param r: changes pic ratio value
   *
   * @return imageView so the image is returned and can be used
   * */
  private ImageView imageCreate(Image i, int x, int y, int h, int w, boolean r)
  {
    ImageView imageView = new ImageView(i);
    //Setting the position of the image 
    imageView.setX(x);
    imageView.setY(y);
    //setting the fit height and width of the image view 
    imageView.setFitHeight(h);
    imageView.setFitWidth(w);
    //Setting the preserve ratio of the image view 
    imageView.setPreserveRatio(r);
    return imageView;
  }

}
