import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


/** The LevelRoom class was made to be higher up on the hierarchy in comparision to the other rooms.
 * This way, all rooms could have access to the same variables and methods making our code more
 * efferent and easier to work with.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 * <pre>
 * Version History:
 * May 31 2019: Class created by Megan. Made the class so that all three levels/rooms could use it.
 *
 * June 2 2019: Edited by Maia, added in the checkTrue and checkDone methods.
 *
 * Approximate time spent working on LevelRoom: 1.5 hours
 * 
 *</pre>
 */
public class LevelRoom{
  private final boolean [] done = {false, false, false, false, false}; //holds the array that determines if all clues have been found


  /**
   * Rect is a useful method that makes a rectangle that is able to be altered by us using
   * the parameters - making creating a rectangle much easier and efficient. 
   *
   * @param x: changes x coordinate value
   * @param y: changes y coordinate value
   * @param h: changes height value
   * @param w: changes width value
   * @param c: changes colour
   *
   * @return imageView so the image is returned and can be used
   * */
  public Rectangle rect (int x, int y, int w, int h, Color c)
  {
    Rectangle rec = new Rectangle();
    rec.setX (x);
    rec.setY(y);
    rec.setWidth(w);
    rec.setHeight(h);
    rec.setFill(c);
    return rec;
  }
  /**
   * ImageView is a useful method that alters an imported image using
   * the parameters - making altering an imported image much easier and efficient. 
   *
   * @param i: chooses image
   * @param x: changes x coordinate value
   * @param y: changes y coordinate value
   * @param h: changes pic height value
   * @param w: changes pic width value
   * @param r: changes pic ratio value
   *
   * @return imageView so the image is returned and can be used
   * */
  public ImageView imageCreate (Image i, int x, int y, int h, int w, boolean r)
  {
    ImageView imageView = new ImageView(i);
    //Setting the position of the image 
    imageView.setX(x);
    imageView.setY(y);
    //setting the fit height and width of the image view 
    imageView.setFitHeight(h);
    imageView.setFitWidth(w);
    //Setting the preserve ratio of the image view 
    imageView.setPreserveRatio(r);
    return imageView;
  }
  /**
   * checkDone is used in all level rooms to determine if all clues have been found. 
   * @return true
   **/
  public boolean checkDone ()
  {
    for (boolean d: done)
    {
      if (!d)
        return false;
    }
    return true;
  }
  /**
   * setTrue is used to set the value of an element in the done array to true. 
   **/
  public void setTrue (int index)
  {
    done[index] = true;
  }
  /**
   * checkTrue is used in all level rooms to determine if a single clue has been found. 
   * @return index of the found clue
   **/
  public boolean checkTrue (int index)
  {
    return done[index];
  }


}




