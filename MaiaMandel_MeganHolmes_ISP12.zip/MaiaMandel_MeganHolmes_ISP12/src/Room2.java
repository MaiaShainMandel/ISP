import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.text.*;

import javafx.scene.control.Label;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.animation.Animation;


/** The Room2 class is similar to the first level but this time instead of identifying the issues,
 * it purposes solutions. It gives the user reassurance when they do something right and find
 * a clue.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 27 2019: Class created by Maia. Image background created externally by Maia and imported.
 *
 * May 29 2019: Edited by Maia, added buttons.
 *
 * May 27 2019: Maia added the clues and the words that appear in the bottom box after a clue is clicked.
 *
 *
 * May 31 2019: Edited by Megan so that the LevelRoom class contained methods used by this class.
 *
 * June 2 2019: Megan added timer.
 *
 * June 4: Megan put in extra images to make the room look nicer.
 *
 * Approximate time spent working on Room2: 3 hours
 *</pre>
 **/
public class Room2 extends LevelRoom {
  /**
  *Holds the basic background colour used in many shapes around the room
  */
  private final Color floor = Color.rgb (217, 223, 228);
  private Group root;
  Scene scene;
  private final Stage stage;

  public Room2 (Stage stage)
  {
    this.stage = stage;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains pictures that were imported. Additionally, a try 
   * and catch to bring the user back to Main Menu. 
   * Also, this method is used to make all of the clues, edit them once clicked, allow for the information at the
   * bottom the be shown, and finally calls inBetweenRoom2 once finished.
   *
   **/
  public void start() {
    stage.setTitle("Room 2");
    Image image = new Image("graphics/Rooms2.png");
    Image help = new Image(("graphics/help.png"));
    Image speechBubbleImage = new Image(("graphics/speechBubble.png"));
    Image showerWater = new Image(("graphics/ShowerWater.png"));
    Image showerWater2 = new Image(("graphics/ShowerWater2.png"));
    Image dryer = new Image(("graphics/HairDryer.png"));
    Image sinkWater = new Image(("graphics/SinkWater.png"));
    Image sink = new Image(("graphics/Sink.png"));
    Image trashBin = new Image(("graphics/TrashBin.png"));
    Image bin = new Image(("graphics/BinEmpty.png"));
    Image lightOn = new Image(("graphics/LightOn.png"));
    Image lightOff = new Image(("graphics/LightsOff.png"));
    Image door = new Image(("graphics/door2.png"));
    Image tub = new Image(("graphics/tub.png"));
    Image mirror = new Image(("graphics/mirror.png"));
    ImageView mirrorView = imageCreate (mirror, 365, 94, 161, 161,true);
    root = new Group(imageCreate (image, 0, 0, 1350, 900, true));
    scene = new Scene(root, 900, 600);

    //Text Facts
    Text showerFact = new Text(280, 545, "Correct! You can't stop taking showers,");
    Text showerFact2 = new Text(240, 575, "but you can switch from hot water to cool water!");
    Text trashFact = new Text(88, 545, "Correct! A lot of bathroom items such as empty soap bottles and toilet");
    Text trashFact2 = new Text(62, 575, "paper rolls are actually recyclable, and should NOT be placed in the garbage!");
    Text sinkFact = new Text(250, 555, "Correct! Sinks should be OFF when not used!");
    Text hairFact = new Text(130, 555, "Correct! Even if the hair dryer is off, it should not be plugged in!");
    Text lightsFact = new Text(160, 555, "Correct! There is still daylight outside, turn off those lights!");

    //Exit Button
    Button btn = new Button();
    btn.setText("Stop");
    btn.setStyle ("-fx-background-color: #f1a6a6");
    btn.setOnAction(new EventHandler<ActionEvent>() {
                      @Override
                      public void handle(ActionEvent event)
                      {
                        MainMenu m = new MainMenu(stage);
                        m.start();
                        stage.setScene (m.scene);
                      }
                    }
    );
    btn.setLayoutX(850);
    btn.setLayoutY(20);
//    //Done button
    Button btn2 = new Button();
    btn2.setText("Got it!");
    btn2.setStyle ("-fx-background-color: #ffffff");
    btn2.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event)
                       {
                         InbetweenRoom2 i2 = new InbetweenRoom2(stage);
                         i2.start();
                         stage.setScene (i2.scene);
                       }
                     }
    );

    btn.setLayoutX(850);
    btn.setLayoutY(20);

    btn2.setLayoutX(415);
    btn2.setLayoutY(440);
    //add button
    root.getChildren().add(btn);
    //draw text box
    root.getChildren ().add(rect(0, 500, 900, 100, Color.web("rgb(145, 191, 223)")));
    root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));

    //shower button
    Button showerBtn = new Button("", imageCreate(showerWater,100,900, 80, 80, true));
    showerBtn.setLayoutX(155);
    showerBtn.setLayoutY(150);
    showerBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(showerBtn);

    showerBtn.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                              root.getChildren().remove(showerBtn);
                              root.getChildren().add(imageCreate(showerWater2,163,154, 80, 80, true));
                              root.getChildren().add(imageCreate (tub, 4, 98, 284, 284, true));
                              root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));
                              root.getChildren().add(showerFact);
                              showerFact.setFill(Color.BLACK);
                              showerFact.setFont(Font.font(22));
                              root.getChildren().add(showerFact2);
                              showerFact2.setFill(Color.BLACK);
                              showerFact2.setFont(Font.font(22));
                              setTrue(0);
                              if (checkDone())
                              {
                                root.getChildren().add(btn2);
                              }

                            }
                          }
    );

    //dryer button
    Button dryerBtn = new Button("", imageCreate(dryer,0,0, 140, 140, true));
    dryerBtn.setLayoutX(696);
    dryerBtn.setLayoutY(269);
    dryerBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(dryerBtn);

    dryerBtn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event) {
                             root.getChildren().remove(dryerBtn);
                             root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));
                             root.getChildren().add(hairFact);
                             hairFact.setFill(Color.BLACK);
                             hairFact.setFont(Font.font(22));
                             setTrue(1);
                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );


    //light button
    Button lightBtn = new Button("", imageCreate(lightOn,0,0, 170, 170, true));
    lightBtn.setLayoutX(350);
    lightBtn.setLayoutY(15);
    lightBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(lightBtn);
    lightBtn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event) {
                             root.getChildren().remove(lightBtn);
                             root.getChildren().add(imageCreate(lightOff,360,20, 170, 170, true));
                             root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));
                             root.getChildren().add(lightsFact);
                             lightsFact.setFill(Color.BLACK);
                             lightsFact.setFont(Font.font(22));
                             setTrue(2);
                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );

    //sink button
    Button sinkBtn = new Button("", imageCreate(sinkWater,0,0, 210, 210, true));
    sinkBtn.setLayoutX(329);
    sinkBtn.setLayoutY(236);
    sinkBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(sinkBtn);
    root.getChildren().add(mirrorView);
    sinkBtn.setOnAction(new EventHandler<ActionEvent>() {
                          @Override
                          public void handle(ActionEvent event) {
                            root.getChildren().remove(sinkBtn);
                            root.getChildren().add(imageCreate (sink, 337, 249, 210, 210, true));
                            root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));
                            root.getChildren().add(sinkFact);
                            sinkFact.setFill(Color.BLACK);
                            sinkFact.setFont(Font.font(22));
                            setTrue(3);
                            if (checkDone())
                            {
                              root.getChildren().add(btn2);
                            }
                          }
                        }
    );

    //trash button
    Button trashBtn = new Button("", imageCreate(trashBin,0,0, 122, 122, true));
    trashBtn.setLayoutX(274);
    trashBtn.setLayoutY(266);
    trashBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(trashBtn);
    trashBtn.setOnAction(new EventHandler<ActionEvent>() {
                           @Override
                           public void handle(ActionEvent event) {
                             root.getChildren().remove(trashBtn);
                             root.getChildren().add(imageCreate (bin, 280, 256, 140, 140, true));
                             root.getChildren (). add (rect (10, 510, 880, 80, Color.WHITE));
                             root.getChildren().add(trashFact);
                             root.getChildren().add(trashFact2);
                             trashFact.setFill(Color.BLACK);
                             trashFact.setFont(Font.font(22));
                             trashFact2.setFill(Color.BLACK);
                             trashFact2.setFont(Font.font(22));
                             setTrue(4);
                             if (checkDone())
                             {
                               root.getChildren().add(btn2);
                             }
                           }
                         }
    );

    //help button
    Text helpText = new Text(125, 26, "Use the information from");
    Text helpTextCont = new Text(125, 41, "the previous level to");
    Text helpTextCont2 = new Text(125, 56, "identify and correct all");
    Text helpTextCont3 = new Text(125, 71, "the environmental issues");
    Text helpTextCont4 = new Text(125, 86, "occurring in this bathroom!");
    ImageView speechBubble = imageCreate (speechBubbleImage, 0, -145, 600, 400, true);
    Button helpBtn = new Button("", imageCreate(help,0,0, 80, 80, true));
    helpBtn.setLayoutX(5);
    helpBtn.setLayoutY(10);
    helpBtn.setStyle("-fx-background-color: #ffe783");
    root.getChildren().add(helpBtn);
    helpBtn.setOnMouseEntered (e -> {
      root.getChildren().add(speechBubble);
      root.getChildren().add(helpText);
      root.getChildren().add(helpTextCont);
      root.getChildren().add(helpTextCont2);
      root.getChildren().add(helpTextCont3);
      root.getChildren().add(helpTextCont4);
      helpText.setFill(Color.BLACK);
      helpText.setFont(Font.font(12));
      helpTextCont.setFill(Color.BLACK);
      helpTextCont.setFont(Font.font(12));
      helpTextCont2.setFill(Color.BLACK);
      helpTextCont2.setFont(Font.font(12));
      helpTextCont3.setFill(Color.BLACK);
      helpTextCont3.setFont(Font.font(12));
      helpTextCont4.setFill(Color.BLACK);
      helpTextCont4.setFont(Font.font(12));
    });
    helpBtn.setOnMouseExited (e -> {
      root.getChildren().remove(helpText);
      root.getChildren().remove(helpTextCont);
      root.getChildren().remove(helpTextCont2);
      root.getChildren().remove(helpTextCont3);
      root.getChildren().remove(helpTextCont4);
      root.getChildren().remove(speechBubble);
    });

    root.getChildren().add(imageCreate (door, 488, 106, 284, 282, true));
    root.getChildren().add(imageCreate (tub, 4, 98, 284, 284, true));
    root.getChildren().add(rect (280, 386, 900, 115, floor));
    root.getChildren().add(rect (225, 386, 70, 30, floor));

    //Timer
    Label timeLabel = new Label("");
    timeLabel.setTextFill(Color.web("#0076a3"));
    DateFormat timeFormat = new SimpleDateFormat( "HH:mm:ss" );
    final Timeline timeline = new Timeline(
            new KeyFrame(
                    Duration.millis(500 ),
                    event -> {
                      final long diff = System.nanoTime()/1000000000- Main.startTime;
                      if ( diff < 0 ) {
                        timeLabel.setText( timeFormat.format( 0 ) );
                      } else {
                        timeLabel.setText((int)diff/60+":"+(int)diff%60+" ");
                      }
                    }
            )
    );
    //format and start animation
    timeLabel.setFont(Font.font("Cambria", 32));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeLabel.setLayoutX (780);
    timeLabel.setLayoutY (5);
    root.getChildren().add((timeLabel));
    timeline.setCycleCount( Animation.INDEFINITE );
    timeline.play();
  }


}




