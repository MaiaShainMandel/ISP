import javafx.application.Application;
import javafx.stage.Stage;

/** The Main class is the parent class containing all the variables needed by all the children class
 * (for example the variables containing the data that makes the timer), and the necessary code to
 * execute the program.
 * 
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 29 2019: Class created by Megan. Made late because we started our project not using OOP, and needed to adjust all classes afterward.
 *
 * May 30 2019: Edited by Megan, made a timer.
 * 
 * Approximate time spent working on Main: 45 minutes 
 *
 *</pre>
 */
public class Main extends Application {
  /**
  *Holds the time that the program starts at, when the user clicks the start button.
  */
  static public long startTime = 0;
  /**
  *Holds the time that the user finishes playing the game, when they reach high scores.
  */
  static public long endTime = 0;
  /**
  *Holds the overall time from start to finish included penalties.
  */
  static public long finalTime = 0;
  /**
  *Holds the time added by a mistake the user makes in room 3.
  */
  static public int penalty;

  public void start(Stage primaryStage) {
    Introduction intro = new Introduction (primaryStage);
    primaryStage.setTitle("Escape Extinction");
    intro.start();
    primaryStage.setScene(intro.scene);
    primaryStage.setResizable(true);
    primaryStage.sizeToScene();
    primaryStage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}