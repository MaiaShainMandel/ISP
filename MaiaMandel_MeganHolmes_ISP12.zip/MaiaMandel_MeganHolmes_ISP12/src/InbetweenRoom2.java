import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


/** The inBetweenRoom2 class was designed to give the user a break between each level. It provides
 * a recap of the previous level, in addition to a summary of the next. This room contains only two buttons so
 * that the user can only leave the game or continue. Since it is technically a room though, and the user
 * has not fully escaped, time will continue. It is very similar to inBetweenRoom1.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 29 2019: Class created by Maia. Graphics made elsewhere and inputted into program.
 *
 * June 2 2019: Edited by Maia, changed button colour and added a quit button instead of only going to room 2.
 *
 * Approximate time spent working on InBetweenRoom2: 45 minutes 
 *</pre>
 */
public class InbetweenRoom2 {
   /**
  *Holds the basic background colour used in many shapes around the room
  */
  private final Color background = Color.rgb (178, 217, 246);
  private final Stage stage;
  Scene scene;

  public InbetweenRoom2(Stage stage)
  {
    this.stage = stage;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains try and catch methods that will return the user to the Main Menu
   * if the Quit button is pressed, as well as room 2 if the Continue button is pressed. 
   *
   **/
  public void start() {
    Image image = new Image(("graphics/inbetweenRoom2.png"));
    Group root = new Group(imageCreate(image, 0, 0, 1350, 900, true));
    scene = new Scene(root, 900, 600, background);
    //Exit Button
    Button btn = new Button();
    btn.setText("Exit To Menu");
    btn.setOnAction(new EventHandler<ActionEvent>() {
                      @Override
                      public void handle(ActionEvent event) {
                        MainMenu m = new MainMenu(stage);
                        m.start();
                        stage.setScene (m.scene);
                      }
                    }
    );
    //Exit Button
    Button btn2 = new Button();
    btn2.setText("Proceed To Next Room");
    btn2.setOnAction(new EventHandler<ActionEvent>() {
                       @Override
                       public void handle(ActionEvent event) {
                         Room3 r3 = new Room3(stage);
                         r3.start();
                         stage.setScene (r3.scene);
                       }
                     }
    );
    btn.setLayoutX(225);
    btn.setLayoutY(280);
    btn2.setLayoutX(205);
    btn2.setLayoutY(330);
    //add button
    root.getChildren().add(btn);
    root.getChildren().add(btn2);
  }
  /**
   * ImageView is a useful method that alters an imported image using
   * the parameters - making altering an imported image much easier and efficient. 
   *
   * @param i: chooses image
   * @param x: changes x coordinate value
   * @param y: changes y coordinate value
   * @param h: changes pic height value
   * @param w: changes pic width value
   * @param r: changes pic ratio value
   *
   * @return imageView so the image is returned and can be used
   * */
  private ImageView imageCreate(Image i, int x, int y, int h, int w, boolean r)
  {
    ImageView imageView = new ImageView(i);
    //Setting the position of the image 
    imageView.setX(x);
    imageView.setY(y);
    //setting the fit height and width of the image view 
    imageView.setFitHeight(h);
    imageView.setFitWidth(w);
    //Setting the preserve ratio of the image view 
    imageView.setPreserveRatio(r);
    return imageView;
  }
}