import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


/** The Instructions class was designed to teach the user how to play the game. It has a
 * description of each room along with specific direction on how it works. There are pictures
 * and simple words that make the game user friendly.
 *
 * @author Maia Mandel and Megan Holmes
 * @version 3 date: 2019.06.08
 *
 * <pre>
 * Version History:
 * May 28 2019: Class created by Maia. Graphics made elsewhere and inputted into program.
 *
 * June 2 2019: Edited by Maia and Megan, changed button colour.
 *
 * Approximate time spent working on Instructions: 1.5 hours 
 *</pre>
 */
public class Instructions {
 /**
  *Holds the basic background colour used in many shapes around the room
  */
  private final Color background = Color.rgb (178, 217, 246);
  Scene scene;
  private final Stage stage;
  public Instructions (Stage stage)
  {
    this.stage = stage;
  }
  /** Start is a public method that sets the screen up, creating buttons, background, and text for the 
   * page to be based around. It contains try and catch methods that will return the user to the Main Menu
   * if the Back To Menu button is pressed.
   *
   **/
  public void start() {
    Image image = new Image(("graphics/Instructions.png"));
    Group root = new Group(imageCreate(image, 0, 0, 1350, 900, true));
    scene = new Scene(root, 900, 600, background);
    //Exit Button
    Button btn = new Button();
    btn.setText("Back To Menu");
    btn.setOnAction(new EventHandler<ActionEvent>() {
                      @Override
                      public void handle(ActionEvent event) {
                        MainMenu m = new MainMenu (stage);
                        m.start();
                        stage.setScene (m.scene);
                      }
                    }
    );
    btn.setLayoutX(750);
    btn.setLayoutY(550);
    //add button
    root.getChildren().add(btn);

  }
  /**
   * ImageView is a useful method that alters an imported image using
   * the parameters - making altering an imported image much easier and efficient. 
   *
   * @param i: chooses image
   * @param x: changes x coordinate value
   * @param y: changes y coordinate value
   * @param h: changes pic height value
   * @param w: changes pic width value
   * @param r: changes pic ratio value
   *
   * @return imageView so the image is returned and can be used
   * */
  private ImageView imageCreate(Image i, int x, int y, int h, int w, boolean r)
  {
    ImageView imageView = new ImageView(i);
    //Setting the position of the image 
    imageView.setX(x);
    imageView.setY(y);
    //setting the fit height and width of the image view 
    imageView.setFitHeight(h);
    imageView.setFitWidth(w);
    //Setting the preserve ratio of the image view 
    imageView.setPreserveRatio(r);
    return imageView;
  }
}